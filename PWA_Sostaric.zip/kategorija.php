<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <link href="//db.onlinewebfonts.com/c/d592bb492b28515987de431a85f70054?family=Marr+Sans+Cond+Web+Bold" rel="stylesheet" type="text/css"/>
    <script src="js/bootstrap.min.js"></script>
    <title>BBC - Home</title>
  </head>
  <header>

    

  </header>
  <body>
    <nav>
      <ul class="nav">
		<li><img src="images/bebec.png" class="logo"></li>
          <li><a href="index.php">Home</a></li>
          <li><a href="kategorija.php?akt=News">News</a></li>
          <li><a href="kategorija.php?akt=Sport">Sport</a></li>
          <li><a href="administracija.php">Administracija</a></li>
          <li><a href="unos.html">Unos</a></li>
      </ul>
    </nav>

    <div class="content">
    <?php

        include 'connect.php';
        define('UPLPATH', 'images/');
        $kategorija = $_GET['akt'];
    ?>

    <div class="aliteracija">
    <h1><?php echo $kategorija ?></h1>
    <div class="row">
        <?php
            
            $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='".$kategorija."'";
            $result = mysqli_query($dbc, $query);
            $i=0;
            while($row = mysqli_fetch_array($result)) {
            
                echo'<div class="onomatopeja col-md-4">';
                echo '<a href="sites/clanak.php?id='.$row['id'].'">';
                echo '<img src="' . UPLPATH . $row['slika'] . '">';
                echo '<h5>';
                echo $row['naslov'];
                echo '</h5>';
                echo'<p>';
                echo $row['sazetak'];
                echo'</p></a>';
                echo '</div>';
            
            }
        ?>
    </div>
    </div>
    </div>
    </div>
    
  
  </body>


  <footer style="background-color: grey">
    <div class="nogalo row">
      <div class="col-md-2"><p>Leon Šoštarić, 2022</p></div>
      <div class="col-md-2 offset-md-8"><p style="float:right">lsostari2@tvz.hr</p></div>
    </div>
  </footer>

</html>