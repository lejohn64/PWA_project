<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <link href="//db.onlinewebfonts.com/c/d592bb492b28515987de431a85f70054?family=Marr+Sans+Cond+Web+Bold" rel="stylesheet" type="text/css"/>
    <script src="js/bootstrap.min.js"></script>
    <title>BBC - Home</title>
  </head>
  <header>

    

  </header>
  <body>
    <nav>
      <ul class="nav">
		<li><img src="images/bebec.png" class="logo"></li>
          <li><a href="index.php">Home</a></li>
          <li><a href="kategorija.php?akt=News">News</a></li>
          <li><a href="kategorija.php?akt=Sport">Sport</a></li>
          <li><a href="administracija.php">Administracija</a></li>
          <li><a href="unos.html">Unos</a></li>
      </ul>
    </nav>

    <div class="content">
    <?php

        if(isset($_POST["title"]) && isset($_POST["about"]) && isset($_POST["content"]) && isset($_FILES["pphoto"]["name"]) && isset($_POST["category"])){
            include "connect.php";
            $title=$_POST["title"];
            $about=$_POST["about"];
            $content=$_POST["content"];
            $photo=$_FILES["pphoto"]["name"];
            $category=$_POST["category"];
            $date = date("Y-m-d");


            if(isset($_POST['archive'])){
                $archive=1;
               }else{
                $archive=0;
               }
 
               $target_dir = 'images/'.$photo;
               move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);
 
 
               $query = "INSERT INTO vijesti ( datum, naslov, sazetak, tekst, slika, kategorija,
               arhiva ) VALUES ( ?, ?, ?, ?, ?, ?, ?)";
 
               $stmt = mysqli_stmt_init($dbc);
 
               if (mysqli_stmt_prepare($stmt, $query)){
                 
                 mysqli_stmt_bind_param($stmt,'ssssssi',$date, $title, $about, $content, $photo, $category, $archive);
                 
                 mysqli_stmt_execute($stmt);
               }
                
               echo " Uneseno.";
 
               mysqli_close($dbc);
              
 
             }
        

    ?>
    </div>
    </div>
    </div>
    </div>
  
  </body>


  <footer style="background-color: grey">
    <div class="nogalo row">
      <div class="col-md-2"><p>Leon Šoštarić, 2022</p></div>
      <div class="col-md-2 offset-md-8"><p style="float:right">lsostari2@tvz.hr</p></div>
    </div>
  </footer>

</html>