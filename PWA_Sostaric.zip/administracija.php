<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <link href="//db.onlinewebfonts.com/c/d592bb492b28515987de431a85f70054?family=Marr+Sans+Cond+Web+Bold" rel="stylesheet" type="text/css"/>
    <script src="js/bootstrap.min.js"></script>
    <title>BBC - Home</title>
  </head>
  <header>

    

  </header>
  <body>
    <nav>
        
      <ul class="nav">
		<li><img src="images/bebec.png" class="logo"></li>
          <li><a href="index.php">Home</a></li>
          <li><a href="kategorija.php?akt=News">News</a></li>
          <li><a href="kategorija.php?akt=Sport">Sport</a></li>
          <li><a href="administracija.php">Administracija</a></li>
          <li><a href="unos.html">Unos</a></li>
      </ul>
    </nav>

    <div class="content">
    <?php
                include 'connect.php';
                define('UPLPATH', 'images/');
                
                $msg = '';

                if(isset($_POST['username']) && isset($_POST['pass'])){

                    $username = $_POST['username']; 
                    $lozinka = $_POST['pass']; 

                    //Provjera postoji li u bazi već korisnik s tim korisničkim imenom 
                    $sql = "SELECT * FROM korisnik WHERE username = ?"; 
                    $stmt = mysqli_stmt_init($dbc); 
                    if (mysqli_stmt_prepare($stmt, $sql)) { 
                        mysqli_stmt_bind_param($stmt, 's',  $username);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_store_result($stmt); 
                    } 
                    mysqli_stmt_bind_result($stmt, $id, $ime, $prezime, $username, $hashpass, $admin);
                    mysqli_stmt_fetch($stmt);
                    
                    if(password_verify($lozinka, $hashpass) && mysqli_stmt_num_rows($stmt) > 0){
                        
                        $_SESSION['id'] = $id;
                        $_SESSION['ime'] = $ime;
                        $_SESSION['prezime'] = $prezime;
                        $_SESSION['username'] = $username;
                        $_SESSION['admin'] = $admin;
                        $_SESSION['login'] = true;
                        
                    } else echo '<div class="col-md-12"><b>Oprez! Unijeli ste krive podadke</b></div>'; 
                    
                    
                } 
            ?>
            <?php         
               
                if(!isset($_SESSION['login']) || $_SESSION['login'] != true){
            ?>
      <form action="" method="POST">
        <label>unesi username: <br/></label>
        <br/>
        <input type="text" name="username"></input>
        <br/>
        <label>unesi password: <br/></label>
        <br/>
        <input type="password" name="pass"></input>
        <br/>
        <br/>
        <input type="submit" name="login" id="login" value="login"></input>
        <a href="registracija.php" ><input type="button" name="reg" id="reg" value="registracija"></input></a>
      </form>

        <?php
            } else if($_SESSION['admin'] == 1){
                if(isset($_POST['delete'])){
                    $id=$_POST['id'];
                    $query = "DELETE FROM vijesti WHERE id=$id ";
                    $result = mysqli_query($dbc, $query);
                }

                if(isset($_POST['update'])){
                    if(is_uploaded_file($_FILES['pphoto']['name'])) $picture = $_FILES['pphoto']['name'];
                    $title=$_POST['title'];
                    $about=$_POST['about'];
                    $content=$_POST['content'];
                    $category=$_POST['category'];
                    if(isset($_POST['archive'])){
                     $archive=1;
                    }else{
                     $archive=0;
                    }
                    if(is_uploaded_file($_FILES['pphoto']['name'])) 
                    {   
                        $target_dir = UPLPATH.$picture;
                        move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);
                    }
                    $id=$_POST['id'];
                    if(is_uploaded_file($_FILES['pphoto']['name'])) $query = "UPDATE vijesti SET naslov='$title', sazetak='$about', tekst='$content', slika='$picture', kategorija='$category', arhiva='$archive' WHERE id=$id ";
                    else $query = "UPDATE vijesti SET naslov='$title', sazetak='$about', tekst='$content', kategorija='$category', arhiva='$archive' WHERE id=$id ";
                    $result = mysqli_query($dbc, $query);
                }

                
                $query = "SELECT * FROM vijesti";
                $result = mysqli_query($dbc, $query);
                while($row = mysqli_fetch_array($result)) {
                //forma za administraciju

                echo '<div class="col-md-12"><form enctype="multipart/form-data" action="" method="POST">
                        <div class="form-item">
                            <label for="title">Naslov vjesti:</label>
                            <div class="form-field">
                                <input type="text" name="title" class="form-field-textual"
                                value="'.$row['naslov'].'">
                            </div>
                        </div>
                        <div class="form-item">
                            <label for="about">Kratki sadržaj vijesti (do 100 znakova):</label>
                            <div class="form-field">
                                <textarea name="about" id="" cols="30" rows="10" class="formfield-textual">'.$row['sazetak'].'</textarea>
                            </div>
                        </div>
                        <div class="form-item">
                            <label for="content">Sadržaj vijesti:</label>
                            <div class="form-field">
                                <textarea name="content" id="" cols="30" rows="10" class="formfield-textual">'.$row['tekst'].'</textarea>
                            </div>
                        </div>
                        <div class="form-item">
                            <label for="pphoto">Slika:</label>
                            <div class="form-field">
                                <input type="file" class="input-text" id="pphoto"
                                value="'.$row['slika'].'" name="pphoto"/> <br><img src="' . UPLPATH .
                                $row['slika'] . '" width=100px>
                            </div>
                        </div>
                        <div class="form-item">
                            <label for="category">Kategorija vijesti:</label>
                                <div class="form-field">
                                <select name="category" id="" class="form-field-textual"
                                value="'.$row['kategorija'].'">
                                <option value="sport">Sport</option>
                                <option value="kultura">Kultura</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-item">
                            <label>Spremiti u arhivu:
                            <div class="form-field">';
                                if($row['arhiva'] == 0) {
                                    echo '<input type="checkbox" name="archive" id="archive"/> Arhiviraj?';
                                } else {
                                    echo '<input type="checkbox" name="archive" id="archive" checked/> Arhiviraj?';
                                }
                                echo '
                                </label>
                            </div>
                        </div>
                        <div class="form-item">
                            <input type="hidden" name="id" class="form-field-textual"
                            value="'.$row['id'].'">
                            <button type="reset" value="Poništi">Poništi</button>
                            <button type="submit" name="update" value="Prihvati">Izmjeni</button>
                            <button type="submit" name="delete" value="Izbriši">Izbriši</button>
                        </div>
                     </form> </div>';
                    
                }
                
                
            } else echo '<p>Bok ' . $_SESSION['username'] . '! Uspješno ste prijavljeni, ali niste administrator.</p>';
            mysqli_close($dbc);
            ?>

    </div>
    </div>
    </div>
    </div>
  
  </body>


  <footer style="background-color: grey">
    <div class="nogalo row">
      <div class="col-md-2"><p>Leon Šoštarić, 2022</p></div>
      <div class="col-md-2 offset-md-8"><p style="float:right">lsostari2@tvz.hr</p></div>
    </div>
  </footer>

</html>