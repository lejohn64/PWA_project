-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2022 at 04:10 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbc`
--
CREATE DATABASE IF NOT EXISTS `bbc` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bbc`;

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `prezime` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `username`, `password`, `admin`) VALUES
(1, 'Leon', 'Šoštarić', 'lsostaric', '$2y$10$LOyamUZm7HAPJAAWRRC9WeIYmQm1NC0WEUS8cd4rokTtZ1JjivIC2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `naslov` varchar(255) NOT NULL,
  `sazetak` varchar(255) NOT NULL,
  `tekst` text NOT NULL,
  `slika` varchar(255) NOT NULL,
  `kategorija` varchar(32) NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(1, '2022-06-23', 'student TVZ-a u neverici', 'Dr. Sc. Zeljko Kovacevic ne gleda kroz prste', 'nece dat 2 sto mu gromova :dab: (rimuje se)', 'gazda.jpg', 'News', 0),
(2, '2022-06-23', 'student TVZ-a u neverici', 'Dr. Sc. Zeljko Kovacevic ne gleda kroz prste', 'nece dat 2 sto mu gromova :dab: (rimuje se)', 'gazda.jpg', 'News', 0),
(3, '2022-06-23', 'student TVZ-a u neverici', 'Dr. Sc. Zeljko Kovacevic ne gleda kroz prste', 'nece dat 2 sto mu gromova :dab: (rimuje se)', 'gazda.jpg', 'News', 0),
(4, '2022-06-23', 'TVZ esports ponovo prvi ', 'TVZ esports skakanje u bazen doslovno su raznjeli sudije ', 'Davor Cafuta: Ponosan sam na nase športski obdarene studente!', 'bugi2889.gif', 'sport', 0),
(5, '2022-06-23', 'TVZ esports ponovo prvi ', 'TVZ esports skakanje u bazen doslovno su raznjeli sudije ', 'Davor Cafuta: Ponosan sam na nase športski obdarene studente!', 'bugi2889.gif', 'sport', 0),
(6, '2022-06-23', 'TVZ esports ponovo prvi ', 'TVZ esports skakanje u bazen doslovno su raznjeli sudije ', 'Davor Cafuta: Ponosan sam na nase športski obdarene studente!', 'bugi2889.gif', 'sport', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
